"""
Chess Game Analysis Deployment Script

This script analyzes a chess game in PGN format and:
1. Predicts the player's ELO using Phase 1 model
2. Detects cheating/smurfing using Phase 2 hybrid system
3. Provides actionable recommendations

Usage: python run_analysis.py game.pgn [--color white|black]
"""

import sys
import argparse
import chess.pgn
import torch
import torch.nn as nn
import numpy as np
import pickle
from pathlib import Path


# ============================================================
# MODEL ARCHITECTURES (MUST MATCH TRAINING NOTEBOOKS!)
# ============================================================

class OptimizedELOPredictor(nn.Module):
    """Phase 1: ELO prediction (from phase1_elo_prediction.ipynb)"""
    def __init__(self, input_dim, hidden_dims=[128, 64], dropout=0.2):
        super().__init__()
        
        self.input_layer = nn.Linear(input_dim, hidden_dims[0])
        self.bn1 = nn.BatchNorm1d(hidden_dims[0])
        
        self.hidden1 = nn.Linear(hidden_dims[0], hidden_dims[1])
        self.bn2 = nn.BatchNorm1d(hidden_dims[1])
        
        self.hidden2 = nn.Linear(hidden_dims[1], hidden_dims[1])
        self.bn3 = nn.BatchNorm1d(hidden_dims[1])
        
        self.output = nn.Linear(hidden_dims[1], 1)
        
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        
    def forward(self, x):
        x = self.relu(self.bn1(self.input_layer(x)))
        x = self.dropout(x)
        
        x = self.relu(self.bn2(self.hidden1(x)))
        identity = x
        x = self.dropout(x)
        
        x = self.bn3(self.hidden2(x))
        x = x + identity  # Residual connection
        x = self.relu(x)
        x = self.dropout(x)
        
        return self.output(x)


class ImprovedAutoencoder(nn.Module):
    """Phase 2: Autoencoder (from phase2_anomaly_detection.ipynb)"""
    def __init__(self, input_dim=24, encoding_dim=8):
        super(ImprovedAutoencoder, self).__init__()
        
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.BatchNorm1d(32),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.2),
            nn.Linear(32, 16),
            nn.BatchNorm1d(16),
            nn.LeakyReLU(0.2),
            nn.Linear(16, encoding_dim),
            nn.Tanh()
        )
        
        self.decoder = nn.Sequential(
            nn.Linear(encoding_dim, 16),
            nn.BatchNorm1d(16),
            nn.LeakyReLU(0.2),
            nn.Linear(16, 32),
            nn.BatchNorm1d(32),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.2),
            nn.Linear(32, 64),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.2),
            nn.Linear(64, input_dim)
        )
    
    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded


class ImprovedCheatDetector(nn.Module):
    """Phase 2: Classifier (from phase2_anomaly_detection.ipynb)"""
    def __init__(self, input_dim=24):
        super(ImprovedCheatDetector, self).__init__()
        
        self.fc1 = nn.Linear(input_dim, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.fc2 = nn.Linear(128, 64)
        self.bn2 = nn.BatchNorm1d(64)
        self.fc3 = nn.Linear(64, 32)
        self.bn3 = nn.BatchNorm1d(32)
        self.fc4 = nn.Linear(32, 16)
        self.bn4 = nn.BatchNorm1d(16)
        self.output = nn.Linear(16, 1)
        self.dropout = nn.Dropout(0.3)
        self.leaky_relu = nn.LeakyReLU(0.2)
    
    def forward(self, x):
        out = self.dropout(self.leaky_relu(self.bn1(self.fc1(x))))
        out = self.dropout(self.leaky_relu(self.bn2(self.fc2(out))))
        out = self.dropout(self.leaky_relu(self.bn3(self.fc3(out))))
        out = self.leaky_relu(self.bn4(self.fc4(out)))
        return self.output(out)


# ============================================================
# LOAD MODELS
# ============================================================

device = torch.device("cpu")

print("Loading models...")
print("-" * 70)

# Phase 1: Auto-detect input dimension from saved model
print("Phase 1 (ELO Prediction)...", end=" ")
phase1_state = torch.load("best_elo_model_v3.pt", map_location=device)
input_dim = phase1_state['input_layer.weight'].shape[1]
hidden_dim1 = phase1_state['input_layer.weight'].shape[0]
hidden_dim2 = phase1_state['hidden1.weight'].shape[0]

elo_model = OptimizedELOPredictor(
    input_dim=input_dim, 
    hidden_dims=[hidden_dim1, hidden_dim2], 
    dropout=0.2
)
elo_model.load_state_dict(phase1_state)
elo_model.eval()
print(f"✓ (input_dim={input_dim})")

# Phase 2: Config
print("Phase 2 (Anomaly Detection)...", end=" ")
with open("phase2_deployment_config.pkl", "rb") as f:
    phase2_config = pickle.load(f)

# Autoencoder
autoencoder = ImprovedAutoencoder(
    input_dim=phase2_config['input_dim'],
    encoding_dim=phase2_config['encoding_dim']
)
autoencoder.load_state_dict(torch.load("best_autoencoder_v2.pt", map_location=device))
autoencoder.eval()

# Classifier
classifier = ImprovedCheatDetector(input_dim=phase2_config['input_dim'])
classifier.load_state_dict(torch.load("best_classifier_v2.pt", map_location=device))
classifier.eval()
print("✓")

print("-" * 70)
print(f"Hybrid system alpha: {phase2_config['best_alpha']:.2f}")
print(f"Decision thresholds: Ban={phase2_config['ban_threshold']:.0%}, Review={phase2_config['review_threshold']:.0%}")
print()


# ============================================================
# FEATURE EXTRACTION
# ============================================================

def extract_phase1_features(game, player_color='white'):
    """
    Extract features for ELO prediction to match training.
    Training used one-hot encoding for categorical features.
    We'll create a simplified approximation with padding.
    """
    board = game.board()
    moves = list(game.mainline_moves())
    
    # Separate moves by color
    if player_color == 'white':
        player_moves = [moves[i] for i in range(0, len(moves), 2)]
    else:
        player_moves = [moves[i] for i in range(1, len(moves), 2)]
    
    n_moves = len(player_moves)
    
    # Reset board
    board = game.board()
    
    # Count move types for this player only
    captures = checks = castles = 0
    for i, move in enumerate(moves):
        if (player_color == 'white' and i % 2 == 0) or (player_color == 'black' and i % 2 == 1):
            if board.is_capture(move):
                captures += 1
            board.push(move)
            if board.is_check():
                checks += 1
            board.pop()
            if board.is_castling(move):
                castles += 1
            board.push(move)
        else:
            board.push(move)
    
    # Opponent rating (most important feature)
    if player_color == 'white':
        opp_rating = float(game.headers.get("BlackElo", "1500"))
    else:
        opp_rating = float(game.headers.get("WhiteElo", "1500"))
    
    # Result
    result_str = game.headers.get("Result", "*")
    if result_str == "1-0":
        won = 1.0 if player_color == 'white' else 0.0
        lost = 0.0 if player_color == 'white' else 1.0
    elif result_str == "0-1":
        won = 0.0 if player_color == 'white' else 1.0
        lost = 1.0 if player_color == 'white' else 0.0
    else:
        won = 0.5
        lost = 0.5
    draw = 1.0 if result_str == "1/2-1/2" else 0.0
    
    # Core numeric features (9 features)
    core_features = [
        opp_rating,           # Most important!
        won,
        lost,
        draw,
        len(moves),           # Total turns
        captures,
        checks,
        captures / max(len(moves), 1),  # capture_rate
        0.0,                  # avg_move_length placeholder
    ]
    
    # Pad to match training input dimension (87 features)
    # The training used one-hot encoded categorical features
    # We'll approximate with zeros for missing categorical features
    padded_features = core_features + [0.0] * (input_dim - len(core_features))
    
    return torch.FloatTensor(padded_features).unsqueeze(0)


def extract_phase2_features(game, player_color='white'):
    """Extract 24 features for anomaly detection"""
    board = game.board()
    moves = list(game.mainline_moves())
    
    if player_color == 'white':
        player_moves_idx = list(range(0, len(moves), 2))
    else:
        player_moves_idx = list(range(1, len(moves), 2))
    
    num_moves = len(player_moves_idx)
    
    # Rating
    if player_color == 'white':
        rating = float(game.headers.get("WhiteElo", "1500"))
    else:
        rating = float(game.headers.get("BlackElo", "1500"))
    
    # Result
    result_str = game.headers.get("Result", "*")
    if result_str == "1-0":
        won = 1.0 if player_color == 'white' else 0.0
    elif result_str == "0-1":
        won = 0.0 if player_color == 'white' else 1.0
    else:
        won = 0.5
    
    # Feature vector (24 features)
    # Note: In production, you'd use Stockfish to compute accuracy features
    features = [
        0.0,       # cheat_percentage (unknown without engine analysis)
        0.0,       # max_cheat_streak
        num_moves, # max_clean_streak
        0.0,       # opening_cheat_pct
        0.0,       # middlegame_cheat_pct
        0.0,       # endgame_cheat_pct
        0.0,       # cheat_consistency
        0.0,       # cheat_increase
        num_moves, # num_moves
        rating,    # rating
        won,       # won
        75.0,      # avg_move_accuracy (placeholder - would need engine)
        15.0,      # std_move_accuracy
        0.20,      # top1_rate (placeholder)
        0.50,      # top3_rate
        0.70,      # top5_rate
        0.10,      # error_rate
        0.05,      # blunder_rate
        0.80,      # accuracy_consistency
        10.0,      # avg_move_time (placeholder - would need timestamps)
        5.0,       # std_move_time
        0.30,      # fast_move_rate
        0.20,      # fast_accurate_rate
        70.0       # endgame_accuracy
    ]
    
    return np.array(features, dtype=np.float32)


# ============================================================
# PREDICTION FUNCTIONS
# ============================================================

def predict_elo(game, player_color='white'):
    """Predict ELO using Phase 1 model"""
    features = extract_phase1_features(game, player_color)
    
    with torch.no_grad():
        prediction = elo_model(features).item()
        # Model output is in original scale (400-3000 range typically)
        predicted_elo = int(np.clip(prediction, 800, 3000))
    
    return predicted_elo


def predict_anomaly(game, player_color='white'):
    """Detect anomalies using hybrid system"""
    features = extract_phase2_features(game, player_color)
    
    # Normalize
    mean = phase2_config['scaler_mean']
    scale = phase2_config['scaler_scale']
    normalized = (features - mean) / scale
    
    x = torch.FloatTensor(normalized).unsqueeze(0)
    
    with torch.no_grad():
        # Autoencoder score
        reconstructed = autoencoder(x)
        ae_mse = torch.mean((x - reconstructed) ** 2).item()
        ae_score = np.clip(ae_mse / 0.1, 0, 1)
        
        # Classifier score
        logits = classifier(x)
        clf_score = torch.sigmoid(logits).item()
    
    # Hybrid score
    alpha = phase2_config['best_alpha']
    hybrid_score = alpha * clf_score + (1 - alpha) * ae_score
    
    # Decision
    if hybrid_score >= phase2_config['ban_threshold']:
        recommendation = "BAN THE USER"
        explanation = f"High confidence cheating detected ({hybrid_score:.1%})"
        confidence = "HIGH"
    elif hybrid_score >= phase2_config['review_threshold']:
        recommendation = "REPORT TO ADMIN FOR HUMAN REVIEW"
        explanation = f"Suspicious behavior detected ({hybrid_score:.1%})"
        confidence = "MEDIUM"
    else:
        recommendation = "NOT CHEATING - LOGGING GAME, UPDATING STATS, CENTRAL REPOSITORY"
        explanation = f"Normal gameplay ({hybrid_score:.1%})"
        confidence = "LOW"
    
    return {
        'hybrid_score': hybrid_score,
        'ae_score': ae_score,
        'clf_score': clf_score,
        'recommendation': recommendation,
        'explanation': explanation,
        'confidence': confidence
    }


# ============================================================
# MAIN ANALYSIS
# ============================================================

def analyze_game(pgn_path, player_color='white'):
    """Analyze a chess game"""
    try:
        with open(pgn_path, "r") as f:
            game = chess.pgn.read_game(f)
        
        if game is None:
            print("❌ Could not parse PGN file")
            return
    except Exception as e:
        print(f"❌ Error: {e}")
        return
    
    # Display game info
    print("=" * 70)
    print("CHESS GAME ANALYSIS")
    print("=" * 70)
    
    print(f"\nGame Information:")
    print(f"  White: {game.headers.get('White', '?')} ({game.headers.get('WhiteElo', '?')})")
    print(f"  Black: {game.headers.get('Black', '?')} ({game.headers.get('BlackElo', '?')})")
    print(f"  Result: {game.headers.get('Result', '*')}")
    print(f"  Event: {game.headers.get('Event', 'Unknown')}")
    print(f"\nAnalyzing: {player_color.upper()} player")
    
    # Phase 1
    print("\n" + "=" * 70)
    print("PHASE 1: ELO PREDICTION")
    print("=" * 70)
    
    predicted_elo = predict_elo(game, player_color)
    stated_elo = game.headers.get(f"{player_color.capitalize()}Elo", "?")
    
    print(f"\nEstimated ELO: {predicted_elo}")
    print(f"   Stated ELO:    {stated_elo}")
    if stated_elo != "?":
        try:
            diff = predicted_elo - int(stated_elo)
        except:
            pass
    
    # Phase 2
    print("\n" + "=" * 70)
    print("PHASE 2: CHEATING/SMURFING DETECTION")
    print("=" * 70)
    
    result = predict_anomaly(game, player_color)
    
    print(f"\nScores:")
    print(f"  Autoencoder: {result['ae_score']:.1%}")
    print(f"  Classifier:  {result['clf_score']:.1%}")
    print(f"  Hybrid:      {result['hybrid_score']:.1%}")
    print(f"  Confidence:  {result['confidence']}")
    
    print(f"\nDECISION:")
    print(f"  {result['recommendation']}")
    print(f"  {result['explanation']}")
    
    print("\n" + "=" * 70)
    
    # Note about limitations
    if result['confidence'] != 'LOW':
        print("\nNOTE: Phase 2 analysis uses placeholder values for move accuracy.")
        print("   For production cheating detection, integrate Stockfish engine analysis.")


# ============================================================
# CLI
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze chess games for cheating")
    parser.add_argument("pgn_file", help="Path to PGN file")
    parser.add_argument("--color", choices=['white', 'black'], default='white')
    
    args = parser.parse_args()
    analyze_game(args.pgn_file, args.color)